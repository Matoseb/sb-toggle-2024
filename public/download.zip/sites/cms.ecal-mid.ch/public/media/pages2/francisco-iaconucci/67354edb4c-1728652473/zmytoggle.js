import useLottie from "https://unpkg.com/@matoseb/uselottie/build/bundle/index.js";

const controller = useLottie({
  container: ".lottie",
  path: "./datadata.json",
  debug: true,
});
let x = 1;
const { onLoad, seek, play, getElem, isPlaying } = controller;

const open = "on-start, on-end";
const close = "close-start, close-end";

onLoad(() => {
  getElem().onclick = () => {
    if (isPlaying(open)) {
      play(close);
    } else {
      play(open);
    }
  };
});
