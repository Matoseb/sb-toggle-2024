import useLottie from "https://unpkg.com/@matoseb/uselottie/build/bundle/index.js";

const audio = new Audio("./aud_0.mp3");
audio.loop = false;

const controller = useLottie({
  container: ".lottie",
  path: "./data.json",
  debug: true,
});

const { onLoad, onComplete, seek, play, isPlaying, getElem, player, random } =
  controller;

const ACTION = {
  pauseHolding: "pause-start, pause-hold",
  pauseRelease: "pause-hold, pause-end",
  playHolding: "play-start, play-hold",
  playRelease: "play-hold, play-end",
  blinkLoop: "blink-start, blink-end",
  blinkLoop2: "blink-end, blink-end2",
};

let timeout;

onLoad(() => {
  seek(ACTION.playRelease, { position: 1 });

  getElem().onpointerdown = () => {
    clearTimeout(timeout);
    if (isPlaying(ACTION.pauseRelease, ACTION.blinkLoop, ACTION.blinkLoop2)) {
      play(ACTION.playHolding, { smooth: true });
    } else if (isPlaying(ACTION.playRelease)) {
      play(ACTION.pauseHolding);
    }
  };

  getElem().onpointerup = () => {
    clearTimeout(timeout);
    if (isPlaying(ACTION.pauseHolding)) {
      play(ACTION.pauseRelease);
      audio.play();
    } else if (isPlaying(ACTION.playHolding)) {
      play(ACTION.playRelease);
      audio.pause();
    }
  };
});

onComplete(() => {
  if (isPlaying(ACTION.pauseRelease)) {
    playBlink();
  } else if (isPlaying(ACTION.blinkLoop, ACTION.blinkLoop2)) {
    clearTimeout(timeout);
    timeout = setTimeout(() => {
      playBlink();
    }, random(500, 2000));
  }
});

function playBlink() {
  play(random([ACTION.blinkLoop, ACTION.blinkLoop2]));
}
