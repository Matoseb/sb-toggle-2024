import useLottie from "https://unpkg.com/@matoseb/uselottie/build/bundle/index.js";

const audio = new Audio("./aud_0.mp3"); // Update with your actual MP3 file path
audio.loop = true; // Set the audio to loop

const controller = useLottie({
  container: ".lottie",
  path: "./data.json",
  debug: true,
});

const { onLoad, seek, play, getElem, isPlaying } = controller;

const ACTION = {
  pauseHolding: "pause-start, pause-hold",
  pauseRelease: "pause-hold, pause-end",
  playHolding: "play-start, play-hold",
  playRelease: "play-hold, play-end",
  // playAudio: "pause-end, play-start",
  // audio: "audio-start, audio-end",
};

onLoad(() => {
  getElem().onpointerdown = () => {
    if (isPlaying(ACTION.pauseRelease)) {
      play(ACTION.playHolding);
    } else {
      play(ACTION.pauseHolding);
    }
  };

  getElem().onpointerup = () => {
    if (isPlaying(ACTION.pauseHolding)) {
      play(ACTION.pauseRelease);
      audio.play();
    } else if (isPlaying(ACTION.playHolding)) {
      play(ACTION.playRelease);
      audio.pause();
    }
  };
});
