import useLottie from "https://unpkg.com/@matoseb/uselottie/build/bundle/index.js";

const controller = useLottie({
  container: ".lottie",
  path: "./data.json",
  debug: true,
});

const ACTION = {
  play: "play-start, play-end",
  pause: "pause-start, pause-end",
};

const { onLoad, play, isPlaying, getElem } = controller;

// // setup
onLoad(() => {
  getElem().onclick = () => {
    if (isPlaying(ACTION.play)) {
      play(ACTION.pause);
    } else {
      play(ACTION.play);
    }
  };
});
