import useLottie from "https://unpkg.com/@matoseb/uselottie/build/bundle/index.js";

const controller = useLottie({
  container: ".lottie",
  path: "./data.json",
  debug: true,
});

// Destructure controller methods
const { onLoad, onComplete, seek, play, isPlaying, getElem } = controller;

const ACTION = {
  on: "on-start, on-end", // state pour jouer l'animation
  active: "active-start, active-end", // state quand l'animation d'apparition est terminée
  off: "off-start, off-end", // state pour retirer l'aimation
  hover: "hover-start, hover-end", // state au survol
  hovered: "is-hovered-start, is-hovered-end", // state quand le survol est terminé
  leave: "leave-start, leave-end", // state du hover quand la souris quitte l'élément
};

// setup
onLoad(() => {
  getElem().onmouseenter = () => {
    if (isPlaying(ACTION.active)) {
      play(ACTION.active);
    } else {
      play(ACTION.hover);
    }
  };

  getElem().onmouseleave = () => {
    if (isPlaying(ACTION.on)) {
      play(ACTION.active);
    } else {
      play(ACTION.leave);
    }
  };

  getElem().onclick = () => {
    if (isPlaying(ACTION.on)) {
      play(ACTION.off);
      setTimeout(() => {
        play(ACTION.hovered);
      }, 250); // 500 millisecondes de délai
    } else if (isPlaying(ACTION.active)) {
      play(ACTION.off);
    } else {
      play(ACTION.on);
    }
  };
});
