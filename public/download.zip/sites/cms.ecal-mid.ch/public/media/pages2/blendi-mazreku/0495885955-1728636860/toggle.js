import useLottie from "https://unpkg.com/@matoseb/uselottie/build/bundle/index.js";

const controller = useLottie({
  container: ".lottie",
  path: "./data.json",
  debug: true,
});

const { onLoad, seek, play, getElem, isPlaying, onComplete } = controller;

let currenstate = "basic";

const ACTIONS = {
  // open: "open-start, open-end",
  press: "hover-end, press-end",
  // close: "close-start, close-end",
  hover: "hover-start, hover-end",
  hoverleave: "hover-end, hover-start",
  active: "release-start, release-end",
  reset: "reset-start, reset-end",
};

onLoad(() => {
  seek(ACTIONS.hoverleave, { position: 1 });

  getElem().onpointerup = () => {
    if (isPlaying(ACTIONS.press)) {
      play(ACTIONS.active, { smooth: true });
    }
  };

  getElem().onpointerdown = () => {
    play(ACTIONS.press);
  };

  getElem().onpointerenter = () => {
    // if state is basic
    if (isPlaying(ACTIONS.hoverleave)) play(ACTIONS.hover);

    console.log("lkajgjkfjkls");
    // return
  };
  getElem().onpointerleave = () => {
    // if state = basic
    if (isPlaying(ACTIONS.hover)) play(ACTIONS.hoverleave);
    //
  };
});

onComplete((event) => {
  if (isPlaying(ACTIONS.reset)) {
    seek(ACTIONS.hoverleave, { position: 1 });
  } else if (isPlaying(ACTIONS.active)) {
    setTimeout(() => {
      play(ACTIONS.reset);
    }, 1000);
  }
});
