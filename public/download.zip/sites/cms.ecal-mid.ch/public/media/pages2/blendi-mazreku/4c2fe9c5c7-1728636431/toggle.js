import useLottie from "https://unpkg.com/@matoseb/uselottie/build/bundle/index.js";

const controller = useLottie({
  container: ".lottie",
  path: "./data.json",
  debug: true,
});

const { onLoad, seek, play, getElem, isPlaying } = controller;

let currenstate = "basic";

const open = "open-start, open-end";
// const close = "close-start, close-end";
const hover = "hover-start, hover-end";
const hoverleave = "hover-end, hover-start";

onLoad(() => {
  getElem().onclick = () => {
    play(open);
  };

  getElem().onpointerenter = () => {
    // if state is basic
    play(hover);
    // return
  };
  getElem().onpointerleave = () => {
    // if state = basic
    play(hoverleave);
    //
  };
});
