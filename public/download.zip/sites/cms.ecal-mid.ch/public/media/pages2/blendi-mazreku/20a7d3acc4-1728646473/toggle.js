import useLottie from "https://unpkg.com/@matoseb/uselottie/build/bundle/index.js";

const controller = useLottie({
  container: ".lottie",
  path: "./data.json",
  debug: true,
});

const { onLoad, seek, play, getElem, isPlaying, onComplete } = controller;

let currenstate = "basic";

const ACTIONS = {
  // open: "open-start, open-end",
  hover: "hover-start, hover-end",
  press: "press-start, press-end",
  // close: "close-start, close-end",
  hoverleave: "hover-end, hover-start",
  active: "press-end, release-end",
  // reset: "reset-start, reset-end",
};

onLoad(() => {
  seek(ACTIONS.hoverleave, { position: 1 });

  getElem().onpointerdown = () => {
    play(ACTIONS.press);
  };

  getElem().onpointerup = () => {
    if (isPlaying(ACTIONS.press)) {
      play(ACTIONS.active, { smooth: true });
    }
  };

  getElem().onpointerenter = () => {
    if (isPlaying(ACTIONS.hoverleave)) {
      play(ACTIONS.hover);

      console.log("lkajgjkfjkls");
      return;
    } else if (isPlaying(ACTIONS.active)) play(ACTIONS.hover);
  };
  getElem().onpointerleave = () => {
    if (isPlaying(ACTIONS.hover)) play(ACTIONS.hoverleave);
  };
});

// onComplete((event) => {
//   if (isPlaying(ACTIONS.reset)) {
//     seek(ACTIONS.hoverleave, { position: 1 });
//   } else if (isPlaying(ACTIONS.active)) {
//     setTimeout(() => {
//       play(ACTIONS.reset);
//     }, 1000);
//   }
// });
