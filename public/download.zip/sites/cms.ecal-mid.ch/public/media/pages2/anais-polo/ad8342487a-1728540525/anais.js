import useLottie from "https://unpkg.com/@matoseb/uselottie/build/bundle/index.js";

const controller1 = useLottie({
  container: ".lottie", // Conteneur pour la première animation
  path: "./data3.json",
  debug: true,
});

const controller2 = useLottie({
  container: ".lottie2",
  path: "./data.json",
  debug: true,
});

const {
  onLoad: onLoad1,
  play: play1,
  getElem: getElem1,
  isPlaying: isPlaying1,
} = controller1;
const {
  onLoad: onLoad2,
  play: play2,
  getElem: getElem2,
  isPlaying: isPlaying2,
} = controller2;

const open1 = "open-start, open-end";
const close1 = "close-start, close-end";

const open2 = "open-start, open-end";
const close2 = "close-start, close-end";

onLoad1(() => {
  getElem1().onclick = () => {
    if (isPlaying1(open1)) {
      play1(close1);
    } else {
      play1(open1);
    }
  };
});

onLoad2(() => {
  getElem2().onclick = () => {
    if (isPlaying2(open2)) {
      play2(close2);
    } else {
      play2(open2);
    }
  };
});
