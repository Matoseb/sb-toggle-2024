import useLottie from "https://unpkg.com/@matoseb/uselottie/build/bundle/index.js";

const controller1 = useLottie({
  container: ".lottie", // Conteneur pour la première animation
  path: "./data.json",
  debug: true,
});

const {
  onLoad: onLoad1,
  play: play1,
  getElem: getElem1,
  isPlaying: isPlaying1,
} = controller1;

const open1 = "open-start, open-end";
const close1 = "close-start, close-end";

onLoad1(() => {
  getElem1().onclick = () => {
    if (isPlaying1(open1)) {
      play1(close1);
    } else {
      play1(open1);
    }
  };
});
