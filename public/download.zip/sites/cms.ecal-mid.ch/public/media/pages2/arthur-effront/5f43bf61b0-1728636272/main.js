window.onload = function(){

    var animation = bodymovin.loadAnimation({
        container: document.getElementById('animation'),
        renderer: 'svg',
        loop: false,
        autoplay: false,
        path: './data.json',
        
    });


    

    animation.addEventListener('DOMLoaded',()=>{


        const segments = [
            {start: 0, end: 10},
            {start: 10, end: 47},
            {start: 47, end: 59},
        ]

        const hitbox = document.querySelector('.hitbox');
       
        console.log(hitbox)

        let segment;

        function hoverOn(){
            if(animation.currentFrame==0 || animation.currentFrame==11){
                segment = segments[0];
                animation.playSegments([segment.start,segment.end],true);
            }
            
            console.log('hovering',animation.currentFrame)
        }
        function hoverOff(){
            animation.playSegments([10,0],true);
            
            console.log('not hovering')
        }

        hitbox.addEventListener('mouseover', hoverOn);
        hitbox.addEventListener('mouseout', hoverOff);

        hitbox.addEventListener('click', function() {
            console.log(animation.currentFrame)
            if(animation.currentFrame==9){
                segment = segments[1];
                animation.playSegments([segment.start,segment.end],true);
                hitbox.removeEventListener('mouseout', hoverOff);
                
            }
            else if(animation.currentFrame==36){
                segment = segments[2];
                animation.playSegments([segment.start,segment.end],true);
                
               
            }
            else if(animation.currentFrame==11){
                segment = segments[0];
                animation.playSegments([segment.start,segment.end],true);
               
            }

            /*else{
                isUp = true;
                animation.playSegments([animation.currentFrame,58],true);
                hitbox.removeEventListener('mouseover', hoverOn);
                hitbox.removeEventListener('mouseout', hoverOff);
            }*/
            
            
            
            /*if(animation.currentFrame==0){
                animation.setSpeed(1);
                animation.play();
            }
            else{
                animation.setSpeed(-1);
                animation.goToAndPlay(10, true)
            }*/
            
        });
        
    })

   

    

}

