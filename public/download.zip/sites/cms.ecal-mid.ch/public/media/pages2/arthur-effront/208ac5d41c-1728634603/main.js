window.onload = function () {
  var animation = bodymovin.loadAnimation({
    container: document.getElementById("animation"),
    renderer: "svg",
    loop: false,
    autoplay: false,
    path: "./data.json",
  });

  animation.addEventListener("DOMLoaded", () => {
    const hitbox = document.querySelector(".hitbox");

    const segments = [
      { start: 0, end: 105 },
      { start: 105, end: 120 },
    ];

    hitbox.addEventListener("click", function () {
      let segment;
      if (animation.currentFrame == 0 || animation.currentFrame == 14) {
        segment = segments[0];
      } else {
        segment = segments[1];
      }

      animation.playSegments([segment.start, segment.end], true);
    });
  });
};
