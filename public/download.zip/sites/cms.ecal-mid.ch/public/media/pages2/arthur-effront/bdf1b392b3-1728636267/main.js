window.onload = function(){

    var animation = bodymovin.loadAnimation({
        container: document.getElementById('animation'),
        renderer: 'svg',
        loop: false,
        autoplay: false,
        path: './data.json',
        
    });


    

    animation.addEventListener('DOMLoaded',()=>{

        const hitbox = document.querySelector('.hitbox');

        hitbox.addEventListener('click', function() {
            if(animation.currentFrame==0){
                animation.setSpeed(1);
                animation.play();
            }
            else{
                animation.setSpeed(-1);
                animation.goToAndPlay(10, true)
            }
            
        });
        
    })

   

    

}

