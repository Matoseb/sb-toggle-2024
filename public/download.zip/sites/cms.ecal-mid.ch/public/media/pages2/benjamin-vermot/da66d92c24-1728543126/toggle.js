import useLottie from "https://unpkg.com/@matoseb/uselottie/build/bundle/index.js";

const controller = useLottie({
  container: ".lottie_1",
  path: "/animations/eyeButton/standard.json",
  debug: true,
});

const {
  onLoad: onLoad,
  play: play,
  getElem: getElem,
  isPlaying: isPlaying,
} = controller;

const open = "open-start, open-end";
const close = "close-start, close-end";

onLoad(() => {
  getElem().onclick = () => {
    if (isPlaying(open)) {
      play(close);
    } else {
      play(open);
    }
  };
});
