import useLottie from "https://unpkg.com/@matoseb/uselottie/build/bundle/index.js";

const controller = useLottie({
  container: ".lottie",
  path: "data.json",
  debug: true,
});

const { onLoad, seek, play, getElem, isPlaying, player } = controller;

const ACTIONS = {
  hover: "hover-start, hover-end",
  hoverActive: "hover2-start, hover2-end",
  active: "active-start, active-end",
  disable: "active2-start, active2-end",
};

onLoad(() => {
  getElem().onpointerenter = () => {
    if (isPlaying(ACTIONS.active, ACTIONS.hoverActive)) {
      play(ACTIONS.hoverActive);
    } else {
      play(ACTIONS.hover);
    }
  };

  getElem().onclick = () => {
    if (isPlaying(ACTIONS.active, ACTIONS.hoverActive)) {
      play(ACTIONS.disable);
    } else {
      play(ACTIONS.active);
    }
  };
});
